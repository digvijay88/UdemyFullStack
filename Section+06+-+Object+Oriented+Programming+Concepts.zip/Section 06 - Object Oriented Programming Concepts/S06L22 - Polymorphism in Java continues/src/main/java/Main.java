import org.studyeasy.Iphone;
import org.studyeasy.Nokia3310;
import org.studyeasy.Phone;

public class Main {
    public static void main(String[] args) {
//        Phone phone = new Phone();
//        phone.feature();
//
//        Nokia3310 nokia = new Nokia3310();
//        nokia.feature();
//
//        Iphone iphone = new Iphone();
//        iphone.feature();


          Phone phone;

          phone = new Phone();
          phone.feature();


    }
}
