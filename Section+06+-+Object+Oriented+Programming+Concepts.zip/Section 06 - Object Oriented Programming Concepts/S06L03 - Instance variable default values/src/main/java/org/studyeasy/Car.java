package org.studyeasy;

public class Car {
    private String doors;
    private String engine;
    private String driver;
    private int speed;


}
