package org.studyeasy;

public class Main {
    public static void main(String[] args) {
        String x;
        Car car = new Car();
       // System.out.println(car.speed);

    }
}
