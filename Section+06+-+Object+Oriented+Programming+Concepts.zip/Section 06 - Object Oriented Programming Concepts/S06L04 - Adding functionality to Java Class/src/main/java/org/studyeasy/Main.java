package org.studyeasy;

public class Main {
    public static void main(String[] args) {
        Car car = new Car();
        System.out.println(car.run());


    }
}
