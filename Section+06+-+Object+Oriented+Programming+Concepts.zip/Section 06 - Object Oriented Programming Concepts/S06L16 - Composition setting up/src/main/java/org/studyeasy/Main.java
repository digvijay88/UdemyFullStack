package org.studyeasy;

import org.studyeasy.laptop.Laptop;

public class Main {

	public static void main(String[] args) {
		Laptop laptop = new Laptop();
		System.out.println(laptop);

	}

}
