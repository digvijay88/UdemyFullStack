package org.studyeasy.vehicles;

public class Bike extends Vehicle{
	private String handle;

	public Bike() {
		handle = "Short";
	}

	public String getHandle() {
		return handle;
	}
}