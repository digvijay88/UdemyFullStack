package org.studyeasy;

import org.studyeasy.vehicles.Bike;

public class Main {
    public static void main(String[] args) {
        Bike bike = new Bike();

        System.out.println(bike.getFuelTank());

    }
}
