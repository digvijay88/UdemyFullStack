package org.studyeasy.vehicles;

public class Car{

    private String steering;
    private String musicSystem;
    private String airConditioner;
    private String fridge;
    private String entertainmentSystem;

}
