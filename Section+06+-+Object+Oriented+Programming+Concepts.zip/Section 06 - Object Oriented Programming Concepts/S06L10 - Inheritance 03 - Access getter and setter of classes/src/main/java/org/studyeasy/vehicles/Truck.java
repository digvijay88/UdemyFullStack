package org.studyeasy.vehicles;

public class Truck{
	private String	steering;
	private String	musicSystem;
	private String airConditioner;
	private int	container;


}
