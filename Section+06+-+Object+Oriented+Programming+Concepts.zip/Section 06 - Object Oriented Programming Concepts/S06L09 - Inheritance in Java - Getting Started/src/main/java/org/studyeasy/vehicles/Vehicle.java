package org.studyeasy.vehicles;

public class Vehicle {

    public String engine;
    public int wheels;
    public int seats;
    public int fuelTank;
    public String lights;


}
