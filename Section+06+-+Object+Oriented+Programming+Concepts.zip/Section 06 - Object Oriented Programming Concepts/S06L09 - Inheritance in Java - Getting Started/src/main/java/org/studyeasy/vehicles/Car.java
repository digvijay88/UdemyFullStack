package org.studyeasy.vehicles;

public class Car{

    public String steering;
    public String musicSystem;
    public String airConditioner;
    public String fridge;
    public String entertainmentSystem;

}
