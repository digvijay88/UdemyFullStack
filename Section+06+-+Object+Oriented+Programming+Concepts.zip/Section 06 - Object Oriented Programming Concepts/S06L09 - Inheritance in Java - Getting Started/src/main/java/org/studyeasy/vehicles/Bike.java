package org.studyeasy.vehicles;

public class Bike extends Vehicle{
	public String handle;


}