package org.studyeasy.vehicles;

public class Truck{
	public String	steering;
	public String	musicSystem;
	public String airConditioner;
	public int	container;


}
