package org.studyeasy;

public class Main {
    public static void main(String[] args) {

        Car car = new Car();
        car.setDoors(4);
        System.out.println(car.getDoors());
    }
}
