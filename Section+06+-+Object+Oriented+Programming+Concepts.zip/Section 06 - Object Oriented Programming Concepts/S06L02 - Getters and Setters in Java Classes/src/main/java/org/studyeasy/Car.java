package org.studyeasy;

public class Car {
    private int doors;
    private String engine;
    private String driver;
    private int speed;

    public void setDoors(int doors){
        doors = doors;
    }

    public int getDoors() {
        return doors;
    }
}
