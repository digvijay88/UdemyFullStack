import org.studyeasy.Phone;

public class Main {
    public static void main(String[] args) {
        Phone phone = new Phone();
        phone.feature();

    }
}
