package org.studyeasy;

public class Nokia3310 extends Phone{
    public void feature(){
        System.out.println("make calls and super reliable");
    }
}
