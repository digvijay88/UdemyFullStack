package org.studyeasy;

public class Iphone extends Phone{
    public void feature(){
        System.out.println("make calls and do smart things");
    }
}
