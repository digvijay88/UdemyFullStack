package org.studyeasy;

public class Phone {
    public void feature(){
        System.out.println("make calls");
    }
}
