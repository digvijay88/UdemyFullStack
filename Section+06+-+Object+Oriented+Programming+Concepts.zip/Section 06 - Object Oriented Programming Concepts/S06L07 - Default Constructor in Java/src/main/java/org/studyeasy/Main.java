package org.studyeasy;

public class Main {
    public static void main(String[] args) {
        Smartphone phone = new Smartphone("Samsung");
        System.out.println(phone.getBrand());

    }
}
