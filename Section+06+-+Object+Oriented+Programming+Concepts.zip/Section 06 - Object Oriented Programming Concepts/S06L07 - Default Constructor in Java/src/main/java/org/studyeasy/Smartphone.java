package org.studyeasy;

public class Smartphone {
    private String brand;

    public Smartphone(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }
}
