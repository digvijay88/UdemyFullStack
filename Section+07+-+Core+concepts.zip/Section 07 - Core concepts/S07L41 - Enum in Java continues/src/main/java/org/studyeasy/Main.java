package org.studyeasy;

public class Main {

    public static void main(String[] args) {
        System.out.println(Learning.COLLECTIONS);
        System.out.println(Learning.COREJAVA.getI());

    }
}