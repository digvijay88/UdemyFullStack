public class TestStatic {
    public static int staticVar=0;

    public static int getStaticVar() {
        return staticVar;
    }

    public static void setStaticVar(int staticVar) {
        TestStatic.staticVar = staticVar;
    }
}
