package org.studyeasy;

public class Lock {
    String code = "123456";

    public String getCode() {
        return code;
    }
}
