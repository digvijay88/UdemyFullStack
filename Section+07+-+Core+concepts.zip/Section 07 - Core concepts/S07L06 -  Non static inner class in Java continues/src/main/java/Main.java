import org.studeasy.Shop;

public class Main {
    public static void main(String[] args) {

        Shop shop = new Shop();
        shop.shopStatus();

    }
}
