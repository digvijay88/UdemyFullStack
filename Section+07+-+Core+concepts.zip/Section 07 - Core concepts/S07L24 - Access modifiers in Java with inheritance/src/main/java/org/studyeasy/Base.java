package org.studyeasy;

public class Base {
     int x = 55;

}
