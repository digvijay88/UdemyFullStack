package org.studyeasy;

public class Sub extends Base{

}
