package org.studyeasy;

import org.studyeasy.Sub;

public class Main {
    public static void main(String[] args) {

        Sub sub = new Sub();
        System.out.println(sub.x);

    }
}
