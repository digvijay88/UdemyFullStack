public class Child {
    public final int x;

    public Child() {
        this.x = 10;
    }

    public Child(int x) {
        this.x = x;
    }

    public int getX() {
        return x;
    }

}
