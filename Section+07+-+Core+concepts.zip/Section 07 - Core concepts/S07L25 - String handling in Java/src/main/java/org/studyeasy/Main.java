package org.studyeasy;

public class Main {
    public static void main(String[] args) {
        String a = "study";
        String b = "easy";
        String c = a+b;
        //System.out.println(c);
        if (c == "studyeasy"){
            System.out.println("studyeasy");
        }else {
            System.out.println("Studyhard");
        }



    }

}
