package org.studyeasy;

public interface Phone {
    String processor();
    int spaceInGb();

}
