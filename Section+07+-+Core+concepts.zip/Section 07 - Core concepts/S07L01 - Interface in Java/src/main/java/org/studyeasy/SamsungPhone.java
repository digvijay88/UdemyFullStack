package org.studyeasy;

public class SamsungPhone {
    public int processor(){
        return 1000;
    }
}
