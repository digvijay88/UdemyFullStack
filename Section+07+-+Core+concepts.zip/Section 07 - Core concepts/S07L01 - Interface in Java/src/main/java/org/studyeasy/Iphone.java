package org.studyeasy;

public class Iphone {
    public String processor(){
        return "A15";
    }
}
