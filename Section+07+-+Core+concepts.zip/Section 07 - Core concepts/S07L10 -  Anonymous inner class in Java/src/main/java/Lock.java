abstract class Lock{
    public abstract void isUnlocked(String key);
    public void test(){
        System.out.println("Test");
    }
}
