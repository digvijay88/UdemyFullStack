package org.studyeasy;

public interface Android {
    String whatsapp();
}
