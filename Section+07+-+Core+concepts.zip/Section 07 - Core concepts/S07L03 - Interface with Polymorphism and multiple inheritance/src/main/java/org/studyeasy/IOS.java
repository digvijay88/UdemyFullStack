package org.studyeasy;

public interface IOS {
    String airdrop();
}
