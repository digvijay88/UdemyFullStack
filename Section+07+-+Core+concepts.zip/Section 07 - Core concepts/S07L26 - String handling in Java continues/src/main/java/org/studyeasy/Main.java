package org.studyeasy;

public class Main {
    public static void main(String[] args) {
        String a = "study";
        String b = "easy";
        String c = a.concat(b);
//        System.out.println(c);
//        if (c.equals("studyeasy")){
//            System.out.println("studyeasy");
//        }else {
//            System.out.println("Studyhard");
//        }
        System.out.println(c);
        System.out.println(c.replace("easy", "Hard"));



    }

}
