package org.studyeasy;

public abstract class Person {
    public void speak(){
        System.out.println("Welcome there!!!!!");
    }
    public abstract void eat();
}
