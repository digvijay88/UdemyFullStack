package org.studyeasy;

public class John extends Person{
    @Override
    public void eat() {
        System.out.println("John eats vegan food");
    }
}
