package org.studyeasy;

public class Pooja extends Person{
    @Override
    public void eat() {
        System.out.println("Pooja eats non-veg food");
    }
}
