public class Child extends Parent{


    public void USA(){
        System.out.println("USA is Fantastic!! with nice people");
    }


}
