public class Main {
    public static void main(String[] args) {

        Child child = new Child();
        child.India();
        child.USA();

    }
}
