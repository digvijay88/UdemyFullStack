public class Parent {
    public final void India(){
        System.out.println("India is great!!");
    }

    public void USA(){
        System.out.println("USA is Fantastic!!");
    }

}
