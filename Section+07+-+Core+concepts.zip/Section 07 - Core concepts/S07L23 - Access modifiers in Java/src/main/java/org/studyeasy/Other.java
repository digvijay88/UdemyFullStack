package org.studyeasy;

public class Other {
    private int x=10;

    public void message(){
        System.out.println(x);
    }
}
