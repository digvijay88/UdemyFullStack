package org.studyeasy;

import org.studyeasy.Other;

public class Main {
    public static void main(String[] args) {
        Other other = new Other();
        //System.out.println(other.x);
        other.message();

    }
}
